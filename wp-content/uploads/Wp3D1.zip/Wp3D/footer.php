<div class="clr"></div>
</div>
<!--/page -->
<div id="page_bottom">
  <div class="footer_resize">
    <div class="box_footer">
      
       <?php if ( !function_exists('dynamic_sidebar')
        || !dynamic_sidebar("Footer") ) : ?>    
<?php endif; ?>
  
      <div class="clr"></div>
    </div>
  </div>
  <div id="footer">
    <div class="footer_resize">
      <div class="text1">&copy; Copyright <?php echo date('Y'); ?> <?php bloginfo('name'); ?>. All Rights Reserved 
        </div>
        <div class="logo_footer">Designed by <a href="http://suv.reviewitonline.net/" title="best suv" targeet="blank">best suv</a> - <a href="http://suv.reviewitonline.net/audi-suv/" title="audi suv" targeet="blank">audi suv</a> - <a href="http://suv.reviewitonline.net/infiniti-suv/" title="infiniti suv" targeet="blank">infiniti suv</a> - <a href="http://suv.reviewitonline.net/toyota-suv/" title="toyota suv" targeet="blank">toyota suv</a>    </div>
    </div>
     <div class="clr"></div>
  </div>
  <div class="clr"></div>
  <!--/footer -->
</div>
</body>
</html>
