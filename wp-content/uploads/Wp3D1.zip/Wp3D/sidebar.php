  <div id="rightcol">
  
  <h2> Subscribe</h2>
  <div id="subscribe">
	
		<ul class="subscribe_icons">
			<li class="subscribe_buzz"><a href="http://google.com/profiles/<?php echo get_theme_mod('google_id'); ?>" rel="nofollow" target="_blank"><?php _e('Buzz', 'themejunkie'); ?></a></li>
			<li class="subscribe_twitter"><a href="http://twitter.com/<?php echo get_theme_mod('twitter_id'); ?>" rel="nofollow" target="_blank"><?php _e('Twitter', 'themejunkie'); ?></a></li>
			<li class="subscribe_facebook"><a href="http://www.facebook.com/<?php echo get_theme_mod('facebook_id'); ?>" rel="nofollow" target="_blank"><?php _e('Facebook', 'themejunkie'); ?></a></li>
			<li class="subscribe_rss"><a href="http://feeds.feedburner.com/<?php echo get_theme_mod('feedburner_id'); ?>" rel="nofollow" target="_blank"><?php _e('RSS', 'themejunkie'); ?></a></li>
			<li class="subscribe_email"><a href="http://feedburner.google.com/fb/a/mailverify?uri=<?php echo get_theme_mod('feedburner_id'); ?>&amp;loc=en_US" rel="nofollow" target="_blank"><?php _e('Email', 'themejunkie'); ?></a></li>
		</ul> <!--end .subscribe_icons-->
		
		<div class="clear"></div>
		
	</div> <!--end #subscribe-->
  
<?php if(get_option('omg_ad') == "Yes")  {include (TEMPLATEPATH . '/sidebarads.php');}  ?>
     <div class="clr"></div>

<?php if(get_option('omg_f') == "Yes")  {include (TEMPLATEPATH . '/featured.php');}  ?>

     <div class="clr"></div>

<?php if(get_option('omg_tw') == "Yes")  {include (TEMPLATEPATH . '/tweet.php');}  ?>


     <div class="clr"></div>
<?php if(get_option('omg_v') == "Yes")  {include (TEMPLATEPATH . '/video.php');}  ?>



     <div class="clr"></div>
    <!--/content -->
  <!--/box -->
  <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar() ) : ?>
  <?php endif; ?>
 
  <!--/box -->
</div>

<!--/rightcol -->



