<?php get_header(); ?>

<div id="columns">
  <div id="centercol">
    <div class="box post full">
      <div class="post-title">
        <h1>Oops, The Page You Are Looking For Cannot Be Located.</h1>
      </div>
      <div class="content border"> </div>
      <!--/content -->
    </div>
    <!--/box -->
  </div>
  <!--/centercol -->
  <?php get_sidebar(); ?>
  <div class="clr"></div>
</div>
<!--/columns -->
<?php get_footer(); ?>
