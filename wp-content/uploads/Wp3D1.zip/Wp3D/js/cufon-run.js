// <![CDATA[
$(function() {
   
Cufon.replace('h1,.block_top p,h2,h3', {hover:true, fontWeight:'bold'});

});
// ]]>