<div class="box ads">
    <div class="wtitle">
      <h2><?php _e('Featured Video'); ?></h2>
    </div>
    <div class="content">
<?php $vid = get_option('omg_video'); echo stripslashes($vid); ?>
</div>
</div>





 